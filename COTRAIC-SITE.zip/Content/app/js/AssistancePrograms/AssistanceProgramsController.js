app.controller('AssistanceProgramsController', ['$scope',

    function ($scope) {
        this.init = function () {

        };
        $scope.doSomething = function () {};
}]);