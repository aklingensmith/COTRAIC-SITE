app.controller('WIAProgramsController', ['$scope',

    function ($scope) {
        this.init = function () {

        };
        $scope.doSomething = function () {};
}]);