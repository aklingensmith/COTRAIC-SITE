app.controller('WIALocationsController', ['$scope',

    function ($scope) {
        this.init = function () {

        };
        $scope.doSomething = function () {};
}]);