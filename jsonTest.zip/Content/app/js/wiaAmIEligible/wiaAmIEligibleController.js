app.controller('WIAAmIEligibleController', ['$scope',

    function ($scope) {
        this.init = function () {

        };
        $scope.doSomething = function () {};
}]);