app.controller('CulturalPowWowController', ['$scope',

    function ($scope) {
        this.init = function () {

        };
        $scope.title = "Pow Wow";
        $scope.content = "Dancing, Singing, Drumming, Arts, Crafts, Museum, Native Foods As a user, I should be able to read the flyer and determine what day and time the Pow Wow is: September 27th, 28th, 2014 12:00PM - 7:00PM(Rain or Shine)";
        $scope.copyrighttext = "2014" + " COTRAIC, Inc.";
}]);