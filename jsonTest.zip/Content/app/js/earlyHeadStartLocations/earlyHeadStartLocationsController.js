app.controller('EarlyHeadStartLocationsController', ['$scope',

    function ($scope) {
        this.init = function () {

        };
        $scope.doSomething = function () {};
}]);